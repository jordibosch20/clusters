##### Lecture and manipulation of our data ######


setwd("~/MESIO/Opt. DS/Clustering")
players <- read.csv2("players.csv", sep = ",")
players <- players[!duplicated(players[,c("short_name")]),]
rownames(players) <- players$short_name
players$player_positions <- sapply(strsplit(players$player_positions, ","), "[", 1)
players$X <- NULL
players$short_name <- NULL
players$preferred_foot <- NULL

# Taking only the numeric variables
num_players <- players[, 3:length(players)]

# Dividing the players' stats by their overall rating to scale the data
sc_players <- num_players/players$overall

# Desired number of players
m <- 500
players_m <- head(players, m)

# Desired number of clusters
k <- 4

# Distance matrix
D <- as.matrix(dist(head(sc_players, m)))
D1 <- cbind(c(1:m), D)
D1 <- rbind(c(0:m), D1)

# Saving the distance matrix for AMPL
write.table(D1, file="distancies_time.txt", row.names=FALSE, col.names=FALSE)

###### AMPL solution to compare with the heuristics #####
ampl <- read.delim("sol_ampl.txt", sep = "")
sol_ampl <- ampl[ampl$X0 != 0,]
sol_ampl$X0 <- NULL

sol <- sol_ampl[1:m,]

sol[, 20:m] <- NA

for (i in 1:floor(m/19)) {
  for (j in 1:m) {
    for (h in 1:19) sol[j, 19*i + h] <- sol_ampl[i*m + j, h]
  }
}
sol[, (m + 1): length(sol)] <- NULL
names(sol) <- rownames(players_m)

# Which players are the medoids of each cluster?
(medoids <- which(sapply(sol, sum) > 0))
med_players <- names(medoids)

# Table with number of players per cluster
for (i in medoids) {
  x <- players_m$player_position[sol[, i] == 1]
  print(assign(med_players[which(medoids == i)], table(x)))
}

# Proportion
for (i in 1:k) {
  assign(paste0("prop_am", i), get(names(medoids)[i]))
  for (name in names(get(paste0("prop_am", i)))) {
    assign(paste0("prop_am", i), assign_in(get(paste0("prop_am", i)), name, get(paste0("prop_am", i))[name]/pos[name]))
  }
  print(get(paste0("prop_am", i)))
}

# Checking that we get the same value for the objective function as AMPL
f_obj <- 0
for (i in medoids) {
  print(f_obj <- f_obj + sum(D[i,sol[, i] == 1]))
}
f_obj

# Solution vector
sol_med <- vector("integer", m)
names(sol_med) <- rownames(players_m)
for (i in 1:k) sol_med[sol[, medoids[i]] == 1] <- i




###### k-means ######

library(tidyverse)  # data manipulation
library(cluster)    # clustering algorithms
library(factoextra)



sc_players_m <- head(sc_players, m)

# Number of players per position
(pos <- table(players_m$player_positions))

# Applying k-means
clust <- kmeans(sc_players_m, centers = k, nstart = 25)

# Visualization of the clusters
windows()
fviz_cluster(clust, data = sc_players_m, geom = "point")

#Visualization of each cluster and each FIFA position
for (i in 1:k) {
  x <- players_m$player_positions[clust$cluster == i]
  print(assign(paste0("k", i), table(x)))
}

for (i in 1:k) {
  assign(paste0("prop", i), get(paste0("k", i)))
  for (name in names(get(paste0("k", i)))) {
    assign(paste0("prop", i), assign_in(get(paste0("prop", i)), name, get(paste0("k", i))[name]/pos[name]))
  }
  print(get(paste0("prop", i)))
}

for (i in names(pos)) {
  aux <- vector("integer")
  assign(i, aux)
  for (clustini in 1:k) {
    for (name in names(get(paste0("prop", clustini)))) {
      if (name == i) {
        aux <- c(aux, rep(clustini, get(paste0("prop", clustini))[i]*pos[i]))
      }
    }
  }
  assign(i, factor(aux, levels = c(1:4)))
}


# Ojective function of the k-medoids, with the clusters obtained
# with the k-means 

medoids_k_means <- vector("character", k)
for (i in 1:k) {
  dist_sum <- with(clust, subset(cluster, cluster == i))
  for (j in 1:length(dist_sum)) {
    dist_sum[j] <- sum(D[names(dist_sum)[j], names(dist_sum)])
  }
  medoids_k_means[i] <- names(dist_sum)[which.min(dist_sum)]
}

medoids_k_means

f_obj_k_means <- 0
for (i in 1:k) {
  name <- medoids_k_means[i]
  print(f_obj_k_means <- f_obj_k_means 
                        + sum(D[name, names(with(clust, subset(cluster, cluster == i)))]))
}
f_obj_k_means

# Comparing the solution vector to obtain the matching percentage
# Clusters have to be adapted to match them

match <- 0
for (i in 1:m) {
  aux_med <- sol_med[i]
  aux_mean <- clust$cluster[i]
  if (aux_mean == 1 & aux_med == 1) match <- match + 1 # Attackers
  if (aux_mean == 4 & aux_med == 2) match <- match + 1 # Goalkeepers
  if (aux_mean == 3 & aux_med == 3) match <- match + 1 # Defenders
  if (aux_mean == 2 & aux_med == 4) match <- match + 1 # Midfielders
}
match

###### MST ######

library(mstknnclust)
library(stats)
library(igraph)

# We create a weighted graph given the distance matrix 
cg <- graph.adjacency(D, mode = "undirected", weighted = TRUE)

# Computation of the minimum spanning tree
mstree <- minimum.spanning.tree(cg)

# Elimination of the k - 1 heaviest edges of our spanning tree to obtain 
# the k clusters
for (i in 1:(k - 1)) {
  mstree <- delete_edges(mstree, which.max(edge_attr(mstree)$weight))
}

# Obtaining the k clusters and their players
str(comp <- components(mstree))


# Ojective function of the k-medoids, with the clusters obtained
# with the MST 

medoids_mst <- vector("character", k)
for (i in 1:k) {
  dist_sum <- with(comp, subset(membership, membership == i))
  for (j in 1:length(dist_sum)) {
    dist_sum[j] <- sum(D[names(dist_sum)[j], names(dist_sum)])
  }
  medoids_mst[i] <- names(dist_sum)[which.min(dist_sum)]
}

medoids_mst

f_obj_mst <- 0
for (i in 1:k) {
  name <- medoids_mst[i]
  print(f_obj_mst <- f_obj_mst 
        + sum(D[name, names(with(comp, subset(membership, membership == i)))]))
}
f_obj_mst

# Comparing the solution vector to obtain the matching percentage

match_mst <- 0
for (i in 1:m) {
  if(sol_med[i] == comp$membership[i]) match_mst <- match_mst + 1
}
match_mst

